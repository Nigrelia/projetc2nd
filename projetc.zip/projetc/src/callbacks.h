#include <gtk/gtk.h>


void
on_ajout_agent_b_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_sexe_agent_male_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_sexe_agent_female_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_voiture_agent_cb_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_aucun_agent_cb_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_moto_agent_cb_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_mod_agent_b_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_chercher_agent_b_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_mod_agent_male_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_mod_agent_female_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_mod_voiture_agent_cb_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_moto_agent_mod_cb_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_aucun_agent_mod_cb_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_supp_agent_b_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_aff_liste_b_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajouter_service_b_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_n_cb_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_m_cb_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_24_cb_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_2_rb_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_1_rb_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_30_rb_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_modifier_service_b_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_chercher_service_b_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ms_1_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ms_30_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ms_2_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_supprimer_service_b_clicked         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ms_24_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ms_m_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ms_n_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
