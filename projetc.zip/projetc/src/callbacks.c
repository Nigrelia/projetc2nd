#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"

int choix=1;
int choix1[]={0,0,0};
int choixx;
int choix2[]={0,0,0};

//agent///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_ajout_agent_b_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
    GtkWidget *id_agent_e;
    GtkWidget *nom_agent_e;
    GtkWidget *prenom_agent_e;
    GtkWidget *contact_agent_e;
    GtkWidget *fonction_agent_e;
    GtkWidget *sal_agent_e;
    GtkWidget *ajout_agent_res;
	GtkWidget * type_agent_c;
	GtkWidget * jour_agent_sb;
	GtkWidget * mois_agent_sb;
	GtkWidget * year_agent_sb;
	

    int veri;
    agent a;
    char res1[200] = "<span foreground='red' font_weight='bold'>L'id déjà existe</span>";
    char res2[200] = "<span foreground='green' font_weight='bold'>Agent ajouté avec succès</span>";
    

    id_agent_e = lookup_widget(button, "id_agent_e");
    nom_agent_e = lookup_widget(button, "nom_agent_e");
    prenom_agent_e = lookup_widget(button, "prenom_agent_e");
    contact_agent_e = lookup_widget(button, "contact_agent_e");
    fonction_agent_e = lookup_widget(button, "fonction_agent_e");
    sal_agent_e = lookup_widget(button, "sal_agent_e");
    ajout_agent_res = lookup_widget(button, "ajout_agent_res");
	type_agent_c = lookup_widget(button,"type_agent_c");

	jour_agent_sb = lookup_widget(button,"jour_agent_sb");
	mois_agent_sb = lookup_widget(button,"mois_agent_sb");
	year_agent_sb = lookup_widget(button,"year_agent_sb");



	
    	strcpy(a.id_agent, gtk_entry_get_text(GTK_ENTRY(id_agent_e)));
    	strcpy(a.nom_agent, gtk_entry_get_text(GTK_ENTRY(nom_agent_e)));
    	strcpy(a.prenom_agent, gtk_entry_get_text(GTK_ENTRY(prenom_agent_e)));
    	strcpy(a.contact, gtk_entry_get_text(GTK_ENTRY(contact_agent_e)));
    	strcpy(a.fonction_agent, gtk_entry_get_text(GTK_ENTRY(fonction_agent_e)));
    	strcpy(a.sal_agent, gtk_entry_get_text(GTK_ENTRY(sal_agent_e)));
	sexe(a.sexe_agent,choix);
	moyen(a.moyen_agent,choix1);
	strcpy(a.type_contact, gtk_combo_box_get_active_text(GTK_COMBO_BOX(type_agent_c)));
	a.date_agent.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour_agent_sb));
	a.date_agent.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois_agent_sb));
	a.date_agent.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(year_agent_sb));
		


	
    

    veri = verify("agents.txt", a.id_agent);
    if (veri == 0) 
    {
        ajout("agents.txt", a);
        gtk_label_set_markup(GTK_LABEL(ajout_agent_res), res2);
    } 
    else 
    {
        gtk_label_set_markup(GTK_LABEL(ajout_agent_res), res1);
    }
	g_timeout_add(2000, clear_label_text, ajout_agent_res);
}




void on_mod_agent_b_clicked(GtkWidget *button, gpointer user_data) {
    GtkWidget *chercher_agent_e;
    GtkWidget *nom_agent_mod_e;
    GtkWidget *prenom_agent_mod_e;
    GtkWidget *contact_agent_mod_e;
    GtkWidget *fonction_agent_mod_e;
    GtkWidget *salaire_agent_mod_e;
    GtkWidget *mod_agent_res;
    GtkWidget *type_agent_mod_c;
    GtkWidget *jour_agent_mod_sb;
    GtkWidget *mois_agent_mod_sb;
    GtkWidget *year_agent_mod_sb;

    
    agent a;
    char res2[200] = "<span foreground='green' font_weight='bold'>Modification avec succès</span>";

    
    chercher_agent_e = lookup_widget(button, "chercher_agent_e");
    nom_agent_mod_e = lookup_widget(button, "nom_agent_mod_e");
    prenom_agent_mod_e = lookup_widget(button, "prenom_agent_mod_e");
    contact_agent_mod_e = lookup_widget(button, "contact_agent_mod_e");
    fonction_agent_mod_e = lookup_widget(button, "fonction_agent_mod_e");
    salaire_agent_mod_e = lookup_widget(button, "salaire_agent_mod_e");
    mod_agent_res = lookup_widget(button, "mod_agent_res");
    type_agent_mod_c = lookup_widget(button,"type_agent_mod_c");
    jour_agent_mod_sb = lookup_widget(button,"jour_agent_mod_sb");
    mois_agent_mod_sb = lookup_widget(button,"mois_agent_mod_sb");
    year_agent_mod_sb = lookup_widget(button,"year_agent_mod_sb");

    
    strcpy(a.id_agent, gtk_entry_get_text(GTK_ENTRY(chercher_agent_e)));
    strcpy(a.nom_agent, gtk_entry_get_text(GTK_ENTRY(nom_agent_mod_e)));
    strcpy(a.prenom_agent, gtk_entry_get_text(GTK_ENTRY(prenom_agent_mod_e)));
    strcpy(a.contact, gtk_entry_get_text(GTK_ENTRY(contact_agent_mod_e)));
    strcpy(a.fonction_agent, gtk_entry_get_text(GTK_ENTRY(fonction_agent_mod_e)));
    strcpy(a.sal_agent, gtk_entry_get_text(GTK_ENTRY(salaire_agent_mod_e)));
    sexe(a.sexe_agent, choix);
    moyen(a.moyen_agent, choix1);
    strcpy(a.type_contact, gtk_combo_box_get_active_text(GTK_COMBO_BOX(type_agent_mod_c)));
    a.date_agent.j = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour_agent_mod_sb));
    a.date_agent.m = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois_agent_mod_sb));
    a.date_agent.a = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(year_agent_mod_sb));

    
    mod_agent("agents.txt", "temp_agents.txt", a.id_agent, &a);

   	
    gtk_label_set_markup(GTK_LABEL(mod_agent_res), res2);
	g_timeout_add(2000, clear_label_text, mod_agent_res);
}



void
on_chercher_agent_b_clicked            (GtkWidget       *button,
                                        gpointer         user_data)
{
	GtkWidget *chercher_agent_e , *chercher_agent_res;
	
	GtkWidget *nom_agent_mod_e;
	GtkWidget *prenom_agent_mod_e;
	GtkWidget *contact_agent_mod_e;
	GtkWidget *fonction_agent_mod_e;
	GtkWidget *salaire_agent_mod_e;
	
	GtkWidget * type_agent_mod_c;
	GtkWidget * jour_agent_mod_sb;
	GtkWidget * mois_agent_mod_sb;
	GtkWidget * year_agent_mod_sb;
	GtkWidget *mod_voiture_agent_cb;
	GtkWidget *moto_agent_mod_cb;
	GtkWidget *aucun_agent_mod_cb;
	GtkWidget *mod_agent_male;
	GtkWidget *mod_agent_female;	



int veri=0;
    agent a;
    char res1[200] = "<span foreground='red' font_weight='bold'>L'id n'existe pas</span>";
    char res2[200] = "<span foreground='green' font_weight='bold'>Agent Trouvé</span>";
	char x [20];
	

	chercher_agent_e = lookup_widget(button, "chercher_agent_e");
    	nom_agent_mod_e = lookup_widget(button, "nom_agent_mod_e");
    	prenom_agent_mod_e = lookup_widget(button, "prenom_agent_mod_e");
    	contact_agent_mod_e = lookup_widget(button, "contact_agent_mod_e");
    	fonction_agent_mod_e = lookup_widget(button, "fonction_agent_mod_e");
    	salaire_agent_mod_e = lookup_widget(button, "salaire_agent_mod_e");
    	chercher_agent_res = lookup_widget(button, "chercher_agent_res");
	type_agent_mod_c = lookup_widget(button,"type_agent_mod_c");
	
	jour_agent_mod_sb = lookup_widget(button,"jour_agent_mod_sb");
	mois_agent_mod_sb = lookup_widget(button,"mois_agent_mod_sb");
	year_agent_mod_sb = lookup_widget(button,"year_agent_mod_sb");
	
	mod_agent_male = lookup_widget(button, "mod_agent_male");
	mod_agent_female = lookup_widget(button, "mod_agent_female");


	mod_voiture_agent_cb=lookup_widget(button, "mod_voiture_agent_cb");
	moto_agent_mod_cb=lookup_widget(button, "moto_agent_mod_cb");
	aucun_agent_mod_cb=lookup_widget(button, "aucun_agent_mod_cb");


	strcpy(x, gtk_entry_get_text(GTK_ENTRY(chercher_agent_e)));


veri=verify("agents.txt", x);
if (veri==0)
{
gtk_label_set_markup(GTK_LABEL(chercher_agent_res), res1);
}
	FILE *f = fopen("agents.txt", "r");  
    			if (f == NULL) {
        		printf("erreur \n");
        		return;
    			}
if (veri==1)
{
	while (fscanf(f, "%s %s %s %s %s %s %s %s %s %s %d-%d-%d", 
                  a.id_agent, 
                  a.nom_agent, 
                  a.prenom_agent, 
                  a.sexe_agent, 
                  a.sal_agent, 
                  a.type_contact, 
                  a.contact, 
                  a.moyen_agent, 
                  a.park, 
                  a.fonction_agent, 
                  &a.date_agent.j, 
                  &a.date_agent.m, 
                  &a.date_agent.a) != EOF)
	


	{
	if(strcmp(x,a.id_agent)==0)
	{
	gtk_entry_set_text(GTK_ENTRY(nom_agent_mod_e), a.nom_agent);
	gtk_entry_set_text(GTK_ENTRY(prenom_agent_mod_e), a.prenom_agent);
	gtk_entry_set_text(GTK_ENTRY(salaire_agent_mod_e), a.sal_agent);
	gtk_entry_set_text(GTK_ENTRY(fonction_agent_mod_e), a.fonction_agent);
	gtk_entry_set_text(GTK_ENTRY(contact_agent_mod_e), a.contact);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour_agent_mod_sb),a.date_agent.j);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois_agent_mod_sb),a.date_agent.m);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(year_agent_mod_sb),a.date_agent.a);	
	if (strcmp(a.type_contact, "Téléphone") == 0) 
	{
    	gtk_combo_box_set_active(GTK_COMBO_BOX(type_agent_mod_c), 0); 
	} 
	if (strcmp(a.type_contact, "Email") == 0) 
	{
    	gtk_combo_box_set_active(GTK_COMBO_BOX(type_agent_mod_c), 1); 
	}
	
	if (strcmp(a.sexe_agent, "male") == 0) 
	{
    	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(mod_agent_male), TRUE);
	
	} 
	else if (strcmp(a.sexe_agent, "female") == 0) 
	{
    	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(mod_agent_female), TRUE);
	
	}
	
	if (strcmp(a.moyen_agent, "voiture") == 0) 
	{
    	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(mod_voiture_agent_cb), TRUE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(moto_agent_mod_cb), FALSE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(aucun_agent_mod_cb), FALSE);
	
	} 
	if (strcmp(a.moyen_agent, "_moto") == 0) 
	{
    	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(moto_agent_mod_cb), TRUE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(aucun_agent_mod_cb), FALSE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(mod_voiture_agent_cb), FALSE);
	} 
	if (strcmp(a.moyen_agent, "_aucun") == 0) 
	{
    	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(aucun_agent_mod_cb), TRUE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(mod_voiture_agent_cb), FALSE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(moto_agent_mod_cb), FALSE);
	
	}
	if (strcmp(a.moyen_agent, "voiture_moto_aucun") == 0) 
	{
    	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(mod_voiture_agent_cb), TRUE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(moto_agent_mod_cb), TRUE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(aucun_agent_mod_cb), TRUE);
	
	} 
	if (strcmp(a.moyen_agent, "_moto_aucun") == 0) 
	{
    	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(mod_voiture_agent_cb), FALSE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(moto_agent_mod_cb), TRUE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(aucun_agent_mod_cb), TRUE);
	
	}
	
	if (strcmp(a.moyen_agent, "voiture_moto") == 0) 
	{
    	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(mod_voiture_agent_cb), TRUE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(moto_agent_mod_cb), TRUE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(aucun_agent_mod_cb), FALSE);
	
	}
	
	if (strcmp(a.moyen_agent, "voiture_aucun") == 0) 
	{
    	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(mod_voiture_agent_cb), TRUE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(moto_agent_mod_cb), FALSE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(aucun_agent_mod_cb), TRUE);
	
	}
	

	

	 
	}
	
	}


	gtk_label_set_markup(GTK_LABEL(chercher_agent_res), res2);
	g_timeout_add(2000, clear_label_text, chercher_agent_res);

	}



}











void
on_supp_agent_b_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
char res1[200] = "<span foreground='red' font_weight='bold'>L'id n'existe pas</span>";
    char res2[200] = "<span foreground='green' font_weight='bold'>Suppression avec succès</span>";
int t;
agent a;
GtkWidget *supp_agent_e;
GtkWidget *supp_agent_res;
supp_agent_e = lookup_widget(button, "supp_agent_e");
supp_agent_res = lookup_widget(button, "supp_agent_res");
strcpy(a.id_agent, gtk_entry_get_text(GTK_ENTRY(supp_agent_e)));
t=verify("agents.txt",a.id_agent);

if(t==1)
{
supp_agent("agents.txt","temp_agents.txt",a.id_agent);
gtk_label_set_markup(GTK_LABEL(supp_agent_res), res2);
}
else
{
gtk_label_set_markup(GTK_LABEL(supp_agent_res), res1);
}

g_timeout_add(2000, clear_label_text, supp_agent_res);

}


void
on_aff_liste_b_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_sexe_agent_male_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
    choix = 1;


}


void
on_sexe_agent_female_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
    choix = 2;

}


void
on_mod_agent_male_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
    choix = 1;

}


void
on_mod_agent_female_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
    choix = 2;
}


void on_voiture_agent_cb_toggled(GtkToggleButton *togglebutton, gpointer user_data) {
    if (gtk_toggle_button_get_active(togglebutton)) {
        choix1[0] = 1;
    } else {
        choix1[0] = 0;
    }
}

void on_aucun_agent_cb_toggled(GtkToggleButton *togglebutton, gpointer user_data) {
    if (gtk_toggle_button_get_active(togglebutton)) {
        choix1[2] = 1;
    } else {
        choix1[2] = 0;
    }
}

void on_moto_agent_cb_toggled(GtkToggleButton *togglebutton, gpointer user_data) {
    if (gtk_toggle_button_get_active(togglebutton)) {
        choix1[1] = 1;
    } else {
        choix1[1] = 0;
    }
}



void
on_mod_voiture_agent_cb_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton)) {
        choix1[0] = 1;
    } else {
        choix1[0] = 0;
    }

}


void
on_moto_agent_mod_cb_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton)) {
        choix1[1] = 1;
    } else {
        choix1[1] = 0;
    }

}


void
on_aucun_agent_mod_cb_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

 if (gtk_toggle_button_get_active(togglebutton)) {
        choix1[2] = 1;
    } else {
        choix1[2] = 0;
    }

}






//service///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void on_ajouter_service_b_clicked(GtkWidget *button, gpointer user_data) {
    GtkWidget *s_id, *s_ta, *s_a, *s_resultat_l,*s_ty;
    service s;
    int veri;
    const char *res1 = "<span foreground='red' font_weight='bold'>L'id déjà existe</span>";
    const char *res2 = "<span foreground='green' font_weight='bold'>Service ajouté avec succès</span>";

    
    s_id = lookup_widget(button, "s_id");
    s_ta = lookup_widget(button, "s_ta");
    s_a = lookup_widget(button, "s_a");
    s_resultat_l = lookup_widget(button, "s_resultat_l");
	s_ty=lookup_widget(button,"s_ty");
    
    strcpy(s.id_service, gtk_entry_get_text(GTK_ENTRY(s_id)));
    strcpy(s.tarif, gtk_entry_get_text(GTK_ENTRY(s_ta)));
    strcpy(s.autres_services, gtk_entry_get_text(GTK_ENTRY(s_a)));
	strcpy(s.type_service, gtk_combo_box_get_active_text(GTK_COMBO_BOX(s_ty)));
    
    //strcpy(s.type_service, "autres");
    //strcpy(s.dispo, "matin");
   // strcpy(s.duree_estime, "1h");
	duree (s.duree_estime,choixx);
	dispo(s.dispo, choix2) ;

    
    veri = verifier_service("services.txt", s.id_service);

    
    if (veri == 0) {
        ajouter_service("services.txt", s);
        gtk_label_set_markup(GTK_LABEL(s_resultat_l), res2);
    } else {
        gtk_label_set_markup(GTK_LABEL(s_resultat_l), res1);
    }
}



void
on_n_cb_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if (gtk_toggle_button_get_active(togglebutton)) {
        choix2[2] = 1;
    } else {
        choix2[2] = 0;
    }

}


void
on_m_cb_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if (gtk_toggle_button_get_active(togglebutton)) {
        choix2[1] = 1;
    } else {
        choix2[1] = 0;
    }
}


void
on_24_cb_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if (gtk_toggle_button_get_active(togglebutton)) {
        choix2[0] = 1;
    } else {
        choix2[0] = 0;
    }

}


void
on_2_rb_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
    choixx = 3;
}


void
on_1_rb_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
    choixx = 2;
}


void
on_30_rb_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
    choixx = 1;
}


void on_modifier_service_b_clicked(GtkWidget *button, gpointer user_data) {
    GtkWidget *ms_id = lookup_widget(button, "ms_id");
    GtkWidget *ms_a = lookup_widget(button, "ms_a");
    GtkWidget *ms_ty = lookup_widget(button, "ms_ty");
    GtkWidget *ms_ta = lookup_widget(button, "ms_ta");
    GtkWidget *ms_res1 = lookup_widget(button, "ms_res1");

    GtkWidget *ms_30 = lookup_widget(button, "ms_30");
    GtkWidget *ms_1 = lookup_widget(button, "ms_1");
    GtkWidget *ms_2 = lookup_widget(button, "ms_2");

    GtkWidget *ms_24 = lookup_widget(button, "ms_24");
    GtkWidget *ms_m = lookup_widget(button, "ms_m");
    GtkWidget *ms_n = lookup_widget(button, "ms_n");

    service s;
    char res1[200] = "<span foreground='red' font_weight='bold'>L'id n'existe pas</span>";
    char res2[200] = "<span foreground='green' font_weight='bold'>Service modifié avec succès</span>";
    char x[50];

    strcpy(x, gtk_entry_get_text(GTK_ENTRY(ms_id)));
    strcpy(s.id_service, x);
    strcpy(s.autres_services, gtk_entry_get_text(GTK_ENTRY(ms_a)));
    strcpy(s.tarif, gtk_entry_get_text(GTK_ENTRY(ms_ta)));

    strcpy(s.type_service, gtk_combo_box_get_active_text(GTK_COMBO_BOX(ms_ty)));

    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ms_30))) {
        strcpy(s.duree_estime, "30Min");
    } else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ms_1))) {
        strcpy(s.duree_estime, "1H");
    } else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ms_2))) {
        strcpy(s.duree_estime, "2H");
    }

    strcpy(s.dispo, "");
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ms_24))) {
        strcat(s.dispo, "24_H");
    }
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ms_m))) {
        if (strlen(s.dispo) > 0) strcat(s.dispo, "_");
        strcat(s.dispo, "matin");
    }
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ms_n))) {
        if (strlen(s.dispo) > 0) strcat(s.dispo, "_");
        strcat(s.dispo, "nuit");
    }

    int veri = verifier_service("services.txt", s.id_service);
    if (veri == 0) {
        gtk_label_set_markup(GTK_LABEL(ms_res1), res1);
    } else {
        mod_service("services.txt", "temp_services.txt", s.id_service, &s);
        gtk_label_set_markup(GTK_LABEL(ms_res1), res2);
    }
}


void on_chercher_service_b_clicked(GtkWidget *button, gpointer user_data) {
    GtkWidget *ms_id, *ms_a, *ms_ty, *ms_ta;
    GtkWidget *ms_30, *ms_1, *ms_2;
    GtkWidget *ms_24, *ms_m, *ms_n;
    GtkWidget *ms_res1;

    service s;
    int veri = 0;
    char res1[200] = "<span foreground='red' font_weight='bold'>L'id n'existe pas</span>";
    char res2[200] = "<span foreground='green' font_weight='bold'>Service trouvé</span>";
    char chercher_id[50];

    
    ms_id = lookup_widget(button, "ms_id");
    ms_a = lookup_widget(button, "ms_a");
    ms_ty = lookup_widget(button, "ms_ty");
    ms_ta = lookup_widget(button, "ms_ta");
    ms_30 = lookup_widget(button, "ms_30");
    ms_1 = lookup_widget(button, "ms_1");
    ms_2 = lookup_widget(button, "ms_2");
    ms_24 = lookup_widget(button, "ms_24");
    ms_m = lookup_widget(button, "ms_m");
    ms_n = lookup_widget(button, "ms_n");
    ms_res1 = lookup_widget(button, "ms_res1");

   
    strcpy(chercher_id, gtk_entry_get_text(GTK_ENTRY(ms_id)));

   
    veri = verifier_service("services.txt", chercher_id);

    if (veri == 0) {
        gtk_label_set_markup(GTK_LABEL(ms_res1), res1);
        return;
    }

 
    FILE *f = fopen("services.txt", "r");
    if (f == NULL) {
        printf("Erreur \n");
        return;
    }

    while (fscanf(f, "%s %s %s %s %s %s", s.id_service, s.tarif, s.type_service, s.autres_services, s.dispo, s.duree_estime) != EOF) {
        if (strcmp(chercher_id, s.id_service) == 0) {
           
            gtk_entry_set_text(GTK_ENTRY(ms_id), s.id_service);
            gtk_entry_set_text(GTK_ENTRY(ms_a), s.autres_services);
            gtk_spin_button_set_value(GTK_SPIN_BUTTON(ms_ta), atof(s.tarif));

        
            if (strcmp(s.type_service, "Lavage_complet") == 0) {
                gtk_combo_box_set_active(GTK_COMBO_BOX(ms_ty), 0);
            } else if (strcmp(s.type_service, "Lavage_exterieur") == 0) {
                gtk_combo_box_set_active(GTK_COMBO_BOX(ms_ty), 1);
            } else if (strcmp(s.type_service, "Controle_pneu") == 0) {
                gtk_combo_box_set_active(GTK_COMBO_BOX(ms_ty), 2);
            } else if (strcmp(s.type_service, "Autres") == 0) {
                gtk_combo_box_set_active(GTK_COMBO_BOX(ms_ty), 3);
            }

     
            if (strcmp(s.duree_estime, "30Min") == 0) {
                gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_30), TRUE);
            } else if (strcmp(s.duree_estime, "1H") == 0) {
                gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_1), TRUE);
            } else if (strcmp(s.duree_estime, "2H") == 0) {
                gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_2), TRUE);
            }

            if (strcmp(s.dispo, "24_H") == 0) {
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_24), TRUE);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_m), FALSE);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_n), FALSE);
} 
else if (strcmp(s.dispo, "matin") == 0) {
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_24), FALSE);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_m), TRUE);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_n), FALSE);
} 
else if (strcmp(s.dispo, "nuit") == 0) {
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_24), FALSE);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_m), FALSE);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_n), TRUE);
} 
else if (strcmp(s.dispo, "24_H_matin") == 0) {
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_24), TRUE);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_m), TRUE);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_n), FALSE);
} 
else if (strcmp(s.dispo, "24_H_nuit") == 0) {
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_24), TRUE);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_m), FALSE);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_n), TRUE);
} 
else if (strcmp(s.dispo, "matin_nuit") == 0) {
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_24), FALSE);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_m), TRUE);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_n), TRUE);
} 
else if (strcmp(s.dispo, "24_H_matin_nuit") == 0) {
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_24), TRUE);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_m), TRUE);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_n), TRUE);
} 
else {
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_24), FALSE);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_m), FALSE);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ms_n), FALSE);
}

            gtk_label_set_markup(GTK_LABEL(ms_res1), res2);
            break;
        }
    }

    fclose(f);
}





void
on_ms_1_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
    choixx = 2;

}


void
on_ms_30_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
    choixx = 1;

}


void
on_ms_2_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
    choixx = 3;

}


void on_supprimer_service_b_clicked(GtkWidget *button, gpointer user_data) {
    char res1[200] = "<span foreground='red' font_weight='bold'>l'id n'existe pas</span>";
    char res2[200] = "<span foreground='green' font_weight='bold'>Suppression avec succès</span>";
    int t;
    service s;
    GtkWidget *supp_service_e;
    GtkWidget *supp_service_res;

    supp_service_e = lookup_widget(button, "ss_id");
    supp_service_res = lookup_widget(button, "ss_res");

    strcpy(s.id_service, gtk_entry_get_text(GTK_ENTRY(supp_service_e)));

    t = verifier_service("services.txt", s.id_service);

    if (t == 1) {
        supp_service("services.txt", "temp_services.txt", s.id_service);
        gtk_label_set_markup(GTK_LABEL(supp_service_res), res2);
    } else {
        gtk_label_set_markup(GTK_LABEL(supp_service_res), res1);
    }
}


void
on_ms_24_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton)) {
        choix2[0] = 1;
    } else {
        choix2[0] = 0;
    }

}


void
on_ms_m_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton)) {
        choix2[1] = 1;
    } else {
        choix2[1] = 0;
    }

}


void
on_ms_n_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton)) {
        choix2[2] = 1;
    } else {
        choix2[2] = 0;
    }

}

